namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        //Player Stats
        int pMaxHP = 20;
        int pHP = 20;
        int pATKPWR = 5;
        int pMaxMP = 10;
        int pMP = 10;
        int LVLPoints = 0;

        //Enemy Stats
        int eMaxHP = 50;
        int eHP = 50;
        int eATKPWR = 3;



        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void basicAttack_Click(object sender, EventArgs e)
        {
            //When the player clicks the basic attack, it takes the players current attack power and subtracts it with the enemy HP making the enemy take dmg
            eHP -= pATKPWR;
            EnemyHP.Text = eHP.ToString() + "/" + eMaxHP.ToString();
            if (eHP <= 0)
            {
                //Goes to the defeat function
                EnemyDefeat();
            }
            else
            {
                //Makes it the enemys turn
                EnemyTurn();
            }
        }

        private void EnemyTurn()
        {
            //When its the enemmys turn, the enemy will always do a basic attack, subtracting the hp of the player by its attack power
            pHP -= eATKPWR;
            HealthNumTxT.Text = pHP.ToString() + "/" + pMaxHP.ToString();
            if (pHP <= 0)
            {
                MessageBox.Show("Defeat");
                Application.Exit();
            }
        }

        private void EnemyDefeat()
        {
            //Levels up the enemy and give the player 2 level up points
            LVLPoints += 2;
            eMaxHP += 10;
            eHP = eMaxHP;
            eATKPWR += 1;
            EnemyHP.Text = eHP.ToString() + "/" + eMaxHP.ToString();
            LVPoints.Text = LVLPoints.ToString();
        }

        private void MagicAttack_Click(object sender, EventArgs e)
        {
            //When the player clicks the basic attack, it takes the players current attack power * 2 and subtracts it with the enemy HP making the enemy take dmg
            //it also takes away some of the players MP
            if(pMP >= 2)
            {
                eHP -= pATKPWR * 2;
                pMP -= 2;
                magicPoints.Text = pMP.ToString() + "/" + pMaxMP.ToString();
                EnemyHP.Text = eHP.ToString() + "/" + eMaxHP.ToString();
                if (eHP <= 0)
                {
                    //Goes to the defeat function
                    EnemyDefeat();
                }
                else
                {
                    //Makes it the enemy turn
                    EnemyTurn();
                }
            }
        }

        private void heal_Click(object sender, EventArgs e)
        {
            //Fully heals the player at the cost of MP
            if (pMP >= 3)
            {
                pHP = pMaxHP;
                pMP -= 3;
                magicPoints.Text = pMP.ToString() + "/" + pMaxMP.ToString();
                HealthNumTxT.Text = pHP.ToString() + "/" + pMaxHP.ToString();
                EnemyTurn();
            }
        }

        private void addAttack_Click(object sender, EventArgs e)
        {
            //Levels up attack
            if (LVLPoints >= 1)
            {
                LVLPoints--;
                LVPoints.Text = LVLPoints.ToString();
                pATKPWR += 5;
                AttackPower.Text = pATKPWR.ToString();
            }
            else
            {
                MessageBox.Show("You Don't Have Enough Points");
            }
        }

        private void addHealth_Click(object sender, EventArgs e)
        {
            //Levels up HP
            if (LVLPoints >= 1)
            {
                LVLPoints--;
                LVPoints.Text = LVLPoints.ToString();
                pMaxHP += 10;
                pHP = pMaxHP;
                HealthNumTxT.Text = pHP.ToString() + "/" + pMaxHP.ToString();
            }
            else
            {
                MessageBox.Show("You Don't Have Enough Points");
            }
        }

        private void addMP_Click(object sender, EventArgs e)
        {
            if (LVLPoints >= 1)
            {
                LVLPoints--;
                LVPoints.Text = LVLPoints.ToString();
                pMaxMP += 5;
                pMP = pMaxMP;
                magicPoints.Text = pMP.ToString() + "/" + pMaxMP.ToString();
            }
            else
            {
                MessageBox.Show("You Don't Have Enough Points");
            }
        }
    }
}
