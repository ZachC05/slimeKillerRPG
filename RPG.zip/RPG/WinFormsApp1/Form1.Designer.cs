﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            healthLabel = new Label();
            HealthNumTxT = new Label();
            AttackPower = new Label();
            AttackPowerLabel = new Label();
            magicPoints = new Label();
            magicPointsLabel = new Label();
            LVPointsTXT = new Label();
            LVPoints = new Label();
            EnemyHPTxT = new Label();
            EnemyHP = new Label();
            SlimeIMG = new PictureBox();
            basicAttack = new Button();
            MagicAttack = new Button();
            heal = new Button();
            addAttack = new Button();
            addHealth = new Button();
            addMP = new Button();
            ((System.ComponentModel.ISupportInitialize)SlimeIMG).BeginInit();
            SuspendLayout();
            // 
            // healthLabel
            // 
            healthLabel.AutoSize = true;
            healthLabel.Location = new Point(56, 281);
            healthLabel.Name = "healthLabel";
            healthLabel.Size = new Size(42, 15);
            healthLabel.TabIndex = 0;
            healthLabel.Text = "Health";
            // 
            // HealthNumTxT
            // 
            HealthNumTxT.AutoSize = true;
            HealthNumTxT.Location = new Point(56, 309);
            HealthNumTxT.Name = "HealthNumTxT";
            HealthNumTxT.Size = new Size(36, 15);
            HealthNumTxT.TabIndex = 1;
            HealthNumTxT.Text = "20/20";
            // 
            // AttackPower
            // 
            AttackPower.AutoSize = true;
            AttackPower.Location = new Point(67, 244);
            AttackPower.Name = "AttackPower";
            AttackPower.Size = new Size(13, 15);
            AttackPower.TabIndex = 3;
            AttackPower.Text = "5";
            // 
            // AttackPowerLabel
            // 
            AttackPowerLabel.AutoSize = true;
            AttackPowerLabel.Location = new Point(56, 217);
            AttackPowerLabel.Name = "AttackPowerLabel";
            AttackPowerLabel.Size = new Size(77, 15);
            AttackPowerLabel.TabIndex = 2;
            AttackPowerLabel.Text = "Attack Power";
            // 
            // magicPoints
            // 
            magicPoints.AutoSize = true;
            magicPoints.Location = new Point(56, 379);
            magicPoints.Name = "magicPoints";
            magicPoints.Size = new Size(36, 15);
            magicPoints.TabIndex = 5;
            magicPoints.Text = "10/10";
            // 
            // magicPointsLabel
            // 
            magicPointsLabel.AutoSize = true;
            magicPointsLabel.Location = new Point(56, 351);
            magicPointsLabel.Name = "magicPointsLabel";
            magicPointsLabel.Size = new Size(25, 15);
            magicPointsLabel.TabIndex = 4;
            magicPointsLabel.Text = "MP";
            // 
            // LVPointsTXT
            // 
            LVPointsTXT.AutoSize = true;
            LVPointsTXT.Location = new Point(56, 91);
            LVPointsTXT.Name = "LVPointsTXT";
            LVPointsTXT.Size = new Size(88, 15);
            LVPointsTXT.TabIndex = 9;
            LVPointsTXT.Text = "Level Up Points";
            // 
            // LVPoints
            // 
            LVPoints.AutoSize = true;
            LVPoints.Location = new Point(56, 129);
            LVPoints.Name = "LVPoints";
            LVPoints.Size = new Size(13, 15);
            LVPoints.TabIndex = 10;
            LVPoints.Text = "0";
            // 
            // EnemyHPTxT
            // 
            EnemyHPTxT.AutoSize = true;
            EnemyHPTxT.Location = new Point(671, 51);
            EnemyHPTxT.Name = "EnemyHPTxT";
            EnemyHPTxT.Size = new Size(81, 15);
            EnemyHPTxT.TabIndex = 11;
            EnemyHPTxT.Text = "Enemy Health";
            // 
            // EnemyHP
            // 
            EnemyHP.AutoSize = true;
            EnemyHP.Location = new Point(671, 91);
            EnemyHP.Name = "EnemyHP";
            EnemyHP.Size = new Size(36, 15);
            EnemyHP.TabIndex = 12;
            EnemyHP.Text = "50/50";
            // 
            // SlimeIMG
            // 
            SlimeIMG.Image = Properties.Resources._14d8089d56e3a20;
            SlimeIMG.Location = new Point(321, 51);
            SlimeIMG.Name = "SlimeIMG";
            SlimeIMG.Size = new Size(124, 81);
            SlimeIMG.SizeMode = PictureBoxSizeMode.StretchImage;
            SlimeIMG.TabIndex = 13;
            SlimeIMG.TabStop = false;
            // 
            // basicAttack
            // 
            basicAttack.Location = new Point(595, 301);
            basicAttack.Name = "basicAttack";
            basicAttack.Size = new Size(112, 23);
            basicAttack.TabIndex = 14;
            basicAttack.Text = "Basic Attack";
            basicAttack.UseVisualStyleBackColor = true;
            basicAttack.Click += basicAttack_Click;
            // 
            // MagicAttack
            // 
            MagicAttack.Location = new Point(595, 343);
            MagicAttack.Name = "MagicAttack";
            MagicAttack.Size = new Size(112, 23);
            MagicAttack.TabIndex = 15;
            MagicAttack.Text = "Magic Attack";
            MagicAttack.UseVisualStyleBackColor = true;
            MagicAttack.Click += MagicAttack_Click;
            // 
            // heal
            // 
            heal.Location = new Point(595, 379);
            heal.Name = "heal";
            heal.Size = new Size(112, 23);
            heal.TabIndex = 16;
            heal.Text = "Magic Heal";
            heal.UseVisualStyleBackColor = true;
            heal.Click += heal_Click;
            // 
            // addAttack
            // 
            addAttack.Location = new Point(135, 240);
            addAttack.Name = "addAttack";
            addAttack.Size = new Size(28, 23);
            addAttack.TabIndex = 8;
            addAttack.Text = "+";
            addAttack.UseVisualStyleBackColor = true;
            addAttack.Click += addAttack_Click;
            // 
            // addHealth
            // 
            addHealth.Location = new Point(135, 305);
            addHealth.Name = "addHealth";
            addHealth.Size = new Size(28, 23);
            addHealth.TabIndex = 7;
            addHealth.Text = "+";
            addHealth.UseVisualStyleBackColor = true;
            addHealth.Click += addHealth_Click;
            // 
            // addMP
            // 
            addMP.Location = new Point(135, 379);
            addMP.Name = "addMP";
            addMP.Size = new Size(28, 23);
            addMP.TabIndex = 6;
            addMP.Text = "+";
            addMP.UseVisualStyleBackColor = true;
            addMP.Click += addMP_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(heal);
            Controls.Add(MagicAttack);
            Controls.Add(basicAttack);
            Controls.Add(SlimeIMG);
            Controls.Add(EnemyHP);
            Controls.Add(EnemyHPTxT);
            Controls.Add(LVPoints);
            Controls.Add(LVPointsTXT);
            Controls.Add(addAttack);
            Controls.Add(addHealth);
            Controls.Add(addMP);
            Controls.Add(magicPoints);
            Controls.Add(magicPointsLabel);
            Controls.Add(AttackPower);
            Controls.Add(AttackPowerLabel);
            Controls.Add(HealthNumTxT);
            Controls.Add(healthLabel);
            Name = "Form1";
            Text = "Slime Killer RPG";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)SlimeIMG).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label healthLabel;
        private Label HealthNumTxT;
        private Label AttackPower;
        private Label AttackPowerLabel;
        private Label magicPoints;
        private Label magicPointsLabel;
        private Label LVPointsTXT;
        private Label LVPoints;
        private Label EnemyHPTxT;
        private Label EnemyHP;
        private PictureBox SlimeIMG;
        private Button basicAttack;
        private Button MagicAttack;
        private Button heal;
        private Button addAttack;
        private Button addHealth;
        private Button addMP;
    }
}
